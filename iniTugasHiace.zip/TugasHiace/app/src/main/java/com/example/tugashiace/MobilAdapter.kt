package com.example.tugashiace

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.tugashiace.model.Mobil
import com.example.tugashiace.model.Rute
import java.util.*
import kotlin.collections.ArrayList

class MobilAdapter(tujuan: String) : RecyclerView.Adapter<MobilAdapter.MyViewHolder>() {

    //val listrute : Rute?= null

    private val mobilList = ArrayList<Mobil>()
    //
    private val listrute = ArrayList<Rute>()
    private val tujuan = tujuan
    private var listTiket:ArrayList<Any?> = ArrayList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(
            R.layout.mobil_item,
            parent, false
        )
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = mobilList[position]

        //rute
        val cItem = listrute[position]

//        var index = position*5
//        println(this.itemCount)
//        if (index < this.itemCount){
//            holder.Travel.text = listTiket[index].toString()
//            holder.Jam.text = listTiket[index+1].toString()
//
//            //
//            holder.Durasi.text = listTiket[index+2].toString()
//            holder.Harga.text = listTiket[index+3].toString()
//            holder.Tjuan.text = listTiket[index+4].toString()
//        }
//        Log.d("Index", index.toString())

//        val tiket = listTiket[index]
//        Log.d("Tiket", tiket.toString())

//        if (tiket == tujuan){
            holder.Travel.text = currentItem.Travel
            holder.Jam.text = currentItem.Jam

            //
            holder.Durasi.text = cItem.Duration
            holder.Harga.text = cItem.Fee
            holder.Tjuan.text = cItem.Key
//        }

    }

    override fun getItemCount(): Int {
      //  return listTiket.size
        return mobilList.size

         return listrute.size
    }

    fun updateMobilList(mobilList : List<Mobil>){

        this.mobilList.clear()
        this.mobilList.addAll(mobilList)
        notifyDataSetChanged()

    }

//    fun joinList(mobilList: List<Mobil>, listrute: List<Rute>): ArrayList<Any?> {
//        val temp:ArrayList<Any?> = ArrayList()
//        val iterator = mobilList.listIterator()
//        val iterator2 = listrute.listIterator()
//        iterator.forEach { mobil ->
//            iterator2.forEach { rute ->
//                temp.add(mobil.Travel)
//                temp.add(mobil.Jam)
//                temp.add(rute.Duration)
//                temp.add(rute.Fee)
//                temp.add(rute.State)
////                fixList.add(temp)
//            }
//            println(temp.size)
//        }
//        return temp
//    }

    //
    fun updateRuteList(listrute: List<Rute>?) {
        this.listrute.clear()
        this.listrute.addAll(listrute!!)
       // var mylist = joinList(this.mobilList, this.listrute)
      //  this.listTiket.clear()
      //  this.listTiket.addAll(mylist)
        notifyDataSetChanged()
    }

    class MyViewHolder(itemView : View) : RecyclerView.ViewHolder(itemView){

        val Travel : TextView = itemView.findViewById(R.id.travel)
        val Jam : TextView = itemView.findViewById(R.id.jamBerangkat)

        //
        val Durasi : TextView = itemView.findViewById(R.id.durasi)
        val Harga : TextView = itemView.findViewById(R.id.harga)
        val Tjuan : TextView = itemView.findViewById(R.id.state2)

//        val args = this.arguments
//        val tvStateB= args?.getString("rute")
//        Tjuan.text = tvStateB.toString()
    }
}