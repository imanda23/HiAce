package com.example.tugashiace

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import com.example.tugashiace.`interface`.IFirebaseLoadDone
import com.example.tugashiace.databinding.FragmentBerandaBinding
import com.example.tugashiace.model.Rute
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.fragment_beranda.*
import kotlin.collections.ArrayList


class Beranda : Fragment(), IFirebaseLoadDone {
    //initial variabel
    private var _binding: FragmentBerandaBinding? = null
    private val binding get() = _binding!!
    lateinit var ruteRef: DatabaseReference
    lateinit var iFirebaseLoadDone: IFirebaseLoadDone
    var num = 0
    private lateinit var tujuan : String
    /*private lateinit var durasi : String
    private lateinit var harga : String*/


    //menampilkan beranda
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_beranda, container, false)
    }


    //mengambil data titik tujuan dan alamat loket dari Firebase
    override fun onFirebaseLoadSuccess(ruteList: List<Rute>) {
        //Get all names from id
        val rute_name_titles = getRuteNameList (ruteList)
        val rute_address = getRuteAddressList (ruteList)
        val rute_state = getRuteStateList (ruteList)
        /*val rute_duration = getRuteDurationList (ruteList)
        val rute_fee = getRuteFeeList (ruteList)*/

        //create Adapter
        val adapter = ArrayAdapter<String>(requireContext(),android.R.layout.simple_list_item_1,rute_name_titles)
        tvStateB.adapter = adapter

        tvStateB.onItemSelectedListener = object :

            AdapterView.OnItemSelectedListener{
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                tvAddressB.text = rute_address[position]

                val spinner: Spinner = tvStateB
                spinner.onItemSelectedListener = this

                tujuan = rute_state[position]
                /*durasi = rute_duration[position]
                harga = rute_fee[position]*/


            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                TODO("Not yet implemented")
            }

        }

    }

    private fun getRuteAddressList(ruteList: List<Rute>): List<String> {
        val result = ArrayList<String>()
        for(rute in ruteList)
            result.add(rute.Address!!)
        return result
    }

    private fun getRuteNameList(ruteList: List<Rute>): List<String> {
        val result = ArrayList<String>()
        for(rute in ruteList)
            result.add(rute.Key!!)
        return result
    }

    private fun getRuteStateList(ruteList: List<Rute>): List<String> {
        val result = ArrayList<String>()
        for(rute in ruteList)
            result.add(rute.State!!)
        return result
    }

    /*private fun getRuteDurationList(ruteList: List<Rute>): List<String> {
        val result = ArrayList<String>()
        for(rute in ruteList)
            result.add(rute.Duration!!)
        return result
    }

    private fun getRuteFeeList(ruteList: List<Rute>): List<String> {
        val result = ArrayList<String>()
        for(rute in ruteList)
            result.add(rute.Fee!!)
        return result
    }*/

    override fun onFirebaseLoadFailed(message: String) {

    }




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //init interface
        iFirebaseLoadDone = this
        //init DB
        ruteRef = FirebaseDatabase.getInstance().getReference("RUTE");
        //Load Data
        ruteRef.addValueEventListener(object:ValueEventListener{
            var ruteList:MutableList<Rute> = ArrayList<Rute>()
            override fun onCancelled(error: DatabaseError) {
                iFirebaseLoadDone.onFirebaseLoadFailed(error.message)
            }

            override fun onDataChange(snapshot: DataSnapshot) {
                for(ruteSnapShot in snapshot.children)
                    ruteList.add(ruteSnapShot.getValue<Rute>(Rute::class.java!!)!!)
                iFirebaseLoadDone.onFirebaseLoadSuccess(ruteList)
            }

        })


    }



    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentBerandaBinding.bind(view)


        binding.apply {
            //Choose date
            btnPickDate.setOnClickListener {
                val datePickerFragment = DatePickerFragment()
                val supportFragmentManager = requireActivity().supportFragmentManager

                supportFragmentManager.setFragmentResultListener(
                    "REQUEST_KEY",
                    viewLifecycleOwner
                )
                { resultKey, bundle ->
                    if (resultKey == "REQUEST_KEY") {
                        val date = bundle.getString("SELECTED_DATE")
                        tvPickDate.text = date
                    }
                }
                //show
                datePickerFragment.show(supportFragmentManager, "DatePickerFragment")
            }

            btnPickDate2.setOnClickListener {
                val datePickerFragment = DatePickerFragment()
                val supportFragmentManager = requireActivity().supportFragmentManager

                supportFragmentManager.setFragmentResultListener(
                    "REQUEST_KEY",
                    viewLifecycleOwner
                )
                { resultKey, bundle ->
                    if (resultKey == "REQUEST_KEY") {
                        val date = bundle.getString("SELECTED_DATE")
                        tvPickDate2.text = date
                        /*if (resultKey.isEmpty()){
                            Toast.makeText(activity, "Tanggal harus diisi", Toast.LENGTH_SHORT).show()
                        } else {
                            val date = bundle.getString("SELECTED_DATE")
                            tvPickDate2.text = date
                        }*/
                    }
                }

                //show
                datePickerFragment.show(supportFragmentManager, "DatePickerFragment")

            }

            increment.setOnClickListener {
                if (num <= 9) {
                    num++
                    tvPenumpang.text = num.toString()
                }else{
                    Toast.makeText(activity, "Penumpang maksimal 10 orang", Toast.LENGTH_SHORT).show()
                }
            }

            decrement.setOnClickListener {
                if (num >= 2) {
                    num--
                    tvPenumpang.text = num.toString()
                }else{
                    Toast.makeText(activity, "Penumpang minimal 1 orang", Toast.LENGTH_SHORT).show()
                }
            }

            //process switch pulang pergi
            switch1.setOnCheckedChangeListener { compoundButton, onSwitch ->
                //if else nya disini
                if (onSwitch) {
                    relative3.visibility = View.VISIBLE
                }else {
                    relative3.visibility = View.GONE
                }
            }

            btnCariTiket.setOnClickListener {
                val bundle = Bundle()
                bundle.putString("rute", tujuan)
                //bundle.putString("rute", harga.toString())

                val newFragment = ListTiket()
                newFragment.arguments = bundle

                fragmentManager?.beginTransaction()?.replace(R.id.container,newFragment)?.commit()

            }
        }
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }


}




