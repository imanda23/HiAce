package com.example.tugashiace.model

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.tugashiace.MobilRepository

class MobilViewModel : ViewModel() {

    private val repository : MobilRepository
    private val _allMobils = MutableLiveData<List<Mobil>>()
    val allMobils : LiveData<List<Mobil>> = _allMobils

    //
    private val _allRute = MutableLiveData<List<Rute>>()
    val allRute : LiveData<List<Rute>> = _allRute
    //var ruteList:MutableList<Rute> = ArrayList<Rute>()

    init {

        repository = MobilRepository().getInstance()
        repository.loadMobils(_allMobils)

        //
        repository.loadRute(_allRute)
    }
}