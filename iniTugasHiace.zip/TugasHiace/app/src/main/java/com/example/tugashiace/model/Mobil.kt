package com.example.tugashiace.model

data class Mobil(var Travel : String ?= null,
                 var Jam : String ?= null,
                 var Plat : String ?= null
                 )
