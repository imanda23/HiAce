package com.example.tugashiace


import androidx.lifecycle.MutableLiveData
import com.example.tugashiace.model.Mobil
import com.example.tugashiace.model.Rute
import com.google.firebase.database.*



class MobilRepository {

    private val databaseReference : DatabaseReference = FirebaseDatabase.getInstance().getReference("TRAVEL")

    //
    val ruteRef : DatabaseReference = FirebaseDatabase.getInstance().getReference("RUTE");

    @Volatile private var INSTANCE: MobilRepository? = null

    fun getInstance(): MobilRepository {
        return INSTANCE ?: synchronized(this) {

            val instance = MobilRepository()
            INSTANCE = instance
            instance
        }
    }

    fun loadMobils(mobilList: MutableLiveData<List<Mobil>>) {

        databaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {

                try {
                    val _mobilList: List<Mobil> = snapshot.children.map { dataSnapshot ->

                        dataSnapshot.getValue(Mobil::class.java)!!

                    }

                    mobilList.postValue(_mobilList)

                } catch (e: Exception) {

                }
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }

        })

    }

    //
    fun loadRute(listrute: MutableLiveData<List<Rute>>) {

        //panggil database RUTE
        ruteRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                try {
                    val _listrute: List<Rute> = snapshot.children.map { dataSnapshot ->
                        dataSnapshot.getValue(Rute::class.java)!!
                    }

                    listrute.postValue(_listrute)
                } catch (e: Exception){

                }
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }

        })
    }

}